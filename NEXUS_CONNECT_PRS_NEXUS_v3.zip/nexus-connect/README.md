# NEXUS CONNECT V3 — PRS Nexus

Mobile-first, portrait-oriented (9:16 phone experience) responsive PWA prototype.

## Included sections
- Home dashboard
- Explore technology industries (33 paths with external learning/documentation links)
- Learning hub and developer tools
- Project studio (local project submissions)
- Member community directory
- WhatsApp direct contact list and the supplied official PRS Nexus group link
- Events and challenges
- Member profile registration
- Membership card and certificate previews
- Achievement/milestone journal
- Admin desk and production launch checklist
- All-sections page

## Run in Termux
```bash
cd ~/storage/downloads
unzip -o NEXUS_CONNECT_PRS_NEXUS_v3.zip
cd nexus-connect
npx serve . -l 3000
```
Open `http://localhost:3000`.

## Important limitations
This is a front-end prototype. Profile, project, event and achievement entries are stored only in this browser using localStorage. The email is not verified; no verification email is sent. Member lists are not shared between devices. WhatsApp buttons open WhatsApp using the number supplied by the member; they do not send messages automatically. The official group button uses the invite URL supplied by the project owner. Membership ID and certificate are previews only.

Before public launch, connect Firebase Authentication with email verification and Firestore. Use server-side admin role assignment, member approval, Firestore Security Rules, and opt-in privacy controls for WhatsApp numbers. Do not collect or publish members' contact information without their consent.

External learning links open third-party websites. Their content and availability are controlled by those providers.

## Credit
Built by Srijit Biswas
