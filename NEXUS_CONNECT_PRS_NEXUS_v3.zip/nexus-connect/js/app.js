const GROUP_URL="https://chat.whatsapp.com/IwVtLEUNwur6ckytIHzJ8l?s=cl&p=a&iam=2";
const K={profiles:"nexus_v3_profiles",projects:"nexus_v3_projects",events:"nexus_v3_events",achievements:"nexus_v3_achievements"};
const $=id=>document.getElementById(id);
const read=k=>JSON.parse(localStorage.getItem(k)||"[]");
const write=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let profiles=read(K.profiles),projects=read(K.projects),events=read(K.events),achievements=read(K.achievements);
const paths=[
["🐍","Python development","software","Start with Python syntax, automation and scripting.","https://www.python.org/about/gettingstarted/","Python.org beginner guide"],
["🌐","Web development","software","Build websites with HTML, CSS, JavaScript and modern frameworks.","https://developer.mozilla.org/en-US/docs/Learn","MDN Web Docs"],
["⚙️","JavaScript & frontend","software","Learn browser programming, interactive interfaces and frontend engineering.","https://javascript.info/","The Modern JavaScript Tutorial"],
["🧩","Backend & APIs","software","Understand servers, databases, APIs and application architecture.","https://roadmap.sh/backend","Backend Developer Roadmap"],
["📱","Android app development","software","Explore Android development, Kotlin and app architecture.","https://developer.android.com/courses","Android Developers"],
["☕","Java programming","software","Learn Java fundamentals and object-oriented programming.","https://dev.java/learn/","Dev.java learning"],
["🧠","C and C++","software","Study programming fundamentals, memory and performance-focused software.","https://www.learncpp.com/","LearnCpp"],
["🧪","Software testing & QA","software","Learn test design, automation and software quality practices.","https://www.selenium.dev/documentation/","Selenium documentation"],
["🤖","Artificial intelligence","data","Understand AI concepts and build a foundation in intelligent systems.","https://www.ibm.com/think/topics/artificial-intelligence","IBM AI overview"],
["🧮","Machine learning","data","Learn models, training data and practical machine-learning workflows.","https://developers.google.com/machine-learning/crash-course","Google ML Crash Course"],
["📊","Data science","data","Work with data, statistics, Python notebooks and visualisation.","https://www.kaggle.com/learn","Kaggle Learn"],
["🗃️","Data analytics & SQL","data","Learn querying, spreadsheets, dashboards and data storytelling.","https://sqlbolt.com/","SQLBolt interactive lessons"],
["🧬","Deep learning","data","Explore neural networks and deep learning concepts.","https://www.deeplearning.ai/","DeepLearning.AI"],
["🛡️","Cybersecurity","security","Build defensive security knowledge, online safety and security fundamentals.","https://www.cisa.gov/cybersecurity","CISA Cybersecurity"],
["🐧","Linux & command line","security","Learn operating systems, terminals, permissions and shell basics.","https://linuxjourney.com/","Linux Journey"],
["🌐","Networking","security","Understand IP, DNS, routing and network fundamentals.","https://www.netacad.com/courses/networking","Cisco Networking Academy"],
["🔐","Cryptography basics","security","Study encryption concepts and how secure communication works.","https://cryptography.io/en/latest/","Cryptography documentation"],
["🎨","UI/UX design","design","Learn user research, wireframes, interaction design and usability.","https://www.figma.com/resource-library/","Figma resource library"],
["🖌️","Graphic & visual design","design","Explore layout, typography, colour and visual communication.","https://www.canva.com/designschool/","Canva Design School"],
["🧭","Product design","design","Understand product thinking, user needs and design processes.","https://www.nngroup.com/articles/","Nielsen Norman Group articles"],
["☁️","Cloud computing","software","Explore cloud concepts, infrastructure and cloud learning paths.","https://aws.amazon.com/training/","AWS Skill Builder"],
["🚀","DevOps & deployment","software","Learn version control, CI/CD, containers and deployment fundamentals.","https://roadmap.sh/devops","DevOps Roadmap"],
["📦","Git & open source","software","Collaborate on code, use version control and contribute to projects.","https://docs.github.com/en/get-started","GitHub getting started"],
["🦾","Robotics","hardware","Explore robotics, sensors, control systems and programming.","https://www.robotics.org/","Association for Advancing Automation"],
["🔌","Electronics & IoT","hardware","Learn circuits, microcontrollers, sensors and connected devices.","https://docs.arduino.cc/","Arduino documentation"],
["🖥️","Computer hardware","hardware","Understand components, architecture and how computers work.","https://www.cs.cmu.edu/~213/","Computer Systems course materials"],
["🎮","Game development","software","Create games and learn game engines, scripting and design.","https://learn.unity.com/","Unity Learn"],
["⛓️","Blockchain concepts","software","Study distributed ledgers, smart-contract concepts and use cases.","https://ethereum.org/en/developers/","Ethereum developer resources"],
["📡","AR / VR / spatial computing","software","Explore immersive interfaces and spatial computing foundations.","https://learn.unity.com/pathway/vr-development","Unity VR pathway"],
["📈","Tech entrepreneurship","business","Learn how to validate ideas, build products and understand startups.","https://www.startupschool.org/","Y Combinator Startup School"],
["🧑‍💼","Tech careers & portfolios","business","Plan a learning roadmap, portfolio and professional profile.","https://roadmap.sh/","Developer roadmaps"],
["♿","Accessibility & inclusive tech","design","Build digital products that work for people with different needs.","https://www.w3.org/WAI/fundamentals/accessibility-intro/","W3C accessibility introduction"],
["📜","IT certifications","business","Explore entry-level professional learning and certification paths.","https://skillsforall.com/","Cisco Skills for All"]
];
const platforms=[
["🎓","freeCodeCamp","Free coding lessons and hands-on projects.","https://www.freecodecamp.org/"],
["📚","Khan Academy Computing","Beginner-friendly computing and programming lessons.","https://www.khanacademy.org/computing"],
["🧑‍🏫","Coursera","Courses and guided programmes from universities and companies.","https://www.coursera.org/"],
["🧰","edX","University-level online courses across technology subjects.","https://www.edx.org/"],
["🧪","Google for Developers","Learning paths, codelabs and developer documentation.","https://developers.google.com/"],
["🗺️","roadmap.sh","Visual roadmaps for technology roles and skills.","https://roadmap.sh/"]
];
const tools=[
["⌨️","GitHub","Host code, collaborate and manage software projects.","https://github.com/"],
["📝","Replit","Code and experiment in an online development environment.","https://replit.com/"],
["🎨","Figma","Design interfaces and collaborate on prototypes.","https://www.figma.com/"],
["🧑‍💻","Visual Studio Code","Popular code editor with extensions and debugging.","https://code.visualstudio.com/"],
["🗒️","Notion","Organise notes, documentation and project plans.","https://www.notion.so/"],
["🌍","Netlify","Deploy websites and frontend projects.","https://www.netlify.com/"]
];
function go(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));
 document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.tab===page || (t.dataset.tab==="more"&&page==="more")));
 window.scrollTo({top:0,behavior:"smooth"});
 if(page==="community")renderMembers();if(page==="chats")renderChats();if(page==="projects")renderProjects();if(page==="events")renderEvents();if(page==="achievements")renderAchievements();if(page==="admin")renderAdmin();if(page==="membership")renderMembership();
}
document.addEventListener("click",e=>{const b=e.target.closest("[data-go],[data-tab]");if(!b)return;go(b.dataset.go||b.dataset.tab);});
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function initials(n){return (n||"N").trim().split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase();}
function phoneDigits(s){return String(s||"").replace(/\D/g,"");}
function wa(p){return "https://wa.me/"+phoneDigits(p.phone);}
function renderPaths(filter="all",query=""){
 const list=paths.filter(p=>(filter==="all"||p[2]===filter)&&(p[1]+" "+p[3]).toLowerCase().includes(query.toLowerCase()));
 $("path-list").innerHTML=list.map(p=>`<article class="path-card"><div class="path-icon">${p[0]}</div><div class="path-info"><b>${p[1]}</b><small>${p[2].toUpperCase()} · ${p[5]}</small><p>${p[3]}</p></div><a class="arrow-link" href="${p[4]}" target="_blank" rel="noopener" aria-label="Open ${p[1]}">↗</a></article>`).join("")||'<div class="empty">No matching technology paths found.</div>';
}
let currentFilter="all";
$("path-filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;currentFilter=b.dataset.filter;document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===b));renderPaths(currentFilter,$("path-search").value);});
$("path-search").addEventListener("input",()=>renderPaths(currentFilter,$("path-search").value));
function resourceHTML(items){return items.map(x=>`<article class="resource-card"><div class="resource-icon">${x[0]}</div><div class="resource-info"><b>${x[1]}</b><p>${x[2]}</p></div><a class="arrow-link" href="${x[3]}" target="_blank" rel="noopener">↗</a></article>`).join("");}
$("learning-list").innerHTML=resourceHTML(platforms);$("tools-list").innerHTML=resourceHTML(tools);renderPaths();
$("profile-form").addEventListener("submit",e=>{
 e.preventDefault();const email=$("email").value.trim().toLowerCase(),phone=$("phone").value.trim();
 if(phoneDigits(phone).length<10){$("profile-message").textContent="Enter a valid WhatsApp number including country code.";return;}
 const p={name:$("full-name").value.trim(),email,phone,role:$("role").value,skills:$("skills").value.trim(),about:$("about").value.trim(),consent:$("contact-consent").checked};
 const idx=profiles.findIndex(x=>x.email===email);if(idx>=0)profiles[idx]=p;else profiles.push(p);write(K.profiles,profiles);
 $("profile-message").textContent="Profile saved on this device. Email address has NOT been verified.";
 $("avatar-btn").textContent=initials(p.name);renderMembers();renderChats();renderMembership();renderAdmin();
});
function memberHTML(p){return `<article class="member-card"><div class="member-avatar">${initials(p.name)}</div><div class="member-info"><b>${esc(p.name)}</b><small>${esc(p.skills||"PRS Nexus member")} · ${esc(p.role||"Member")}</small></div>${p.consent?`<a class="wa-btn" target="_blank" rel="noopener" href="${wa(p)}">WhatsApp ↗</a>`:"<small>Contact hidden</small>"}</article>`;}
function renderMembers(){const q=($("member-search")?.value||"").toLowerCase();const arr=profiles.filter(p=>(p.name+" "+p.skills).toLowerCase().includes(q));$("member-count").textContent=arr.length;$("stat-members").textContent=profiles.length;$("member-list").innerHTML=arr.length?arr.map(memberHTML).join(""):'<div class="empty">No local profiles yet. Create your profile to get started.</div>';}
$("member-search").addEventListener("input",renderMembers);
function renderChats(){const arr=profiles.filter(p=>p.consent);$("chat-list").innerHTML=arr.length?arr.map(memberHTML).join(""):'<div class="empty">No member contact profiles saved in this browser yet. Members who consent to sharing their WhatsApp contact will appear here.</div>';}
$("project-form").addEventListener("submit",e=>{e.preventDefault();projects.unshift({name:$("project-name").value.trim(),desc:$("project-desc").value.trim(),skills:$("project-skills").value.trim(),date:new Date().toLocaleDateString()});write(K.projects,projects);e.target.reset();renderProjects();renderAdmin();});
function renderProjects(){$("project-list").innerHTML=projects.length?projects.map(p=>`<article class="resource-card"><div class="resource-icon">◇</div><div class="resource-info"><b>${esc(p.name)}</b><small>${esc(p.date)} · ${esc(p.skills||"Open collaboration")}</small><p>${esc(p.desc)}</p></div></article>`).join(""):'<div class="empty">No project ideas yet. Add the first one above.</div>';}
$("event-form").addEventListener("submit",e=>{e.preventDefault();events.push({name:$("event-name").value.trim(),date:$("event-date").value,desc:$("event-desc").value.trim()});write(K.events,events);e.target.reset();renderEvents();renderAdmin();});
function renderEvents(){$("event-list").innerHTML=events.length?events.map(p=>`<article class="resource-card"><div class="resource-icon">✦</div><div class="resource-info"><b>${esc(p.name)}</b><small>${esc(p.date||"DATE TO BE ANNOUNCED")}</small><p>${esc(p.desc)}</p></div></article>`).join(""):'<div class="empty">No events have been added yet.</div>';}
$("achievement-form").addEventListener("submit",e=>{e.preventDefault();achievements.unshift({name:$("achievement-name").value.trim(),desc:$("achievement-desc").value.trim(),date:new Date().toLocaleDateString()});write(K.achievements,achievements);e.target.reset();renderAchievements();});
function renderAchievements(){$("achievement-list").innerHTML=achievements.length?achievements.map(a=>`<article class="resource-card"><div class="resource-icon">★</div><div class="resource-info"><b>${esc(a.name)}</b><small>${esc(a.date)}</small><p>${esc(a.desc)}</p></div></article>`).join(""):'<div class="empty">Your milestones will appear here.</div>';}
function renderMembership(){const p=profiles[0];$("card-name").textContent=p?.name?.toUpperCase()||"YOUR NAME";$("cert-name").textContent=p?.name||"Your Name";$("card-monogram").textContent=initials(p?.name||"N");$("card-id").textContent="ID PENDING";}
function renderAdmin(){$("admin-members").textContent=profiles.length;$("admin-projects").textContent=projects.length;$("admin-events").textContent=events.length;}
$("stat-members").textContent=profiles.length;
renderMembers();renderChats();renderProjects();renderEvents();renderAchievements();renderMembership();renderAdmin();
if("serviceWorker"in navigator&&location.protocol!=="file:")addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
